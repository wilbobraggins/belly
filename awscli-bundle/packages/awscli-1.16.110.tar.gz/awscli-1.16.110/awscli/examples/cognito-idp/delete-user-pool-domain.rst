**To delete a user pool domain**

This example deletes a user pool domain named my-domain.

Command::

  aws cognito-idp delete-user-pool --user-pool-id us-west-2_aaaaaaaaa --domain my-domain

